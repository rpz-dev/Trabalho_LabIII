
package Trabalho;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


public class Teste {
    public static void main(String[] args) {
        
        //Listas dinâmicas.
        List<Usuario> usuarios = new ArrayList<>();
        List<Livro> livros = new ArrayList<>();
        List<Emprestimo> emprestimos = new ArrayList<>();
        
        //Adição de 3 usuários.
        usuarios.add(new Usuario(831492, "Rodrigo", "rodrigop@hotmail.com", "123"));
        usuarios.add(new Usuario(876532, "Cleiton", "cleitinp@hotmail.com", "234"));
        usuarios.add(new Usuario(845214, "Douglas", "Douglassilva@hotmail.com", "555"));
        
        
        //Estrutura para pesquisa de usuários por nome.
        for (Usuario u: usuarios) {
            if (u.getNome().equals("Rodrigo")){
                System.out.println(u);
            }
        }
                
        //Imprimir todos os usuários.
        for (Usuario u: usuarios){
            System.out.println(u);
        }
        
        //Adição de 3 livros.
        livros.add(new Livro(111, "Harry Potter e a Pedra Filosofal", "J. K. Rolling", "volume 1", "rocco", "EUA", 1985));
        livros.add(new Livro(222, "Harry Potter e o Cálice de Fogo", "J. K. Rolling", "volume 2", "rocco", "EUA", 2000));
        livros.add(new Livro(333, "Harry Potter e o Prisioneiro de Azkaban", "J. K. Rolling", "volume 1", "rocco", "EUA", 2001));

        
        //Exibir dados de um livro a partir do ID
        for (Livro lis: livros) {
            if (lis.getIdLivro() == 111){
                System.out.println("");
                System.out.println(lis);
            }
        }
        
        //Imprimir todos os livros.
        for (Livro lis: livros) {
            System.out.println(lis);
        }
        
        //Efetuar um empréstimo.
        emprestimos.add(new Emprestimo(1, 831492, 111, LocalDate.of(2020, 02, 11), LocalDate.of(2020, 03, 11), false));
        emprestimos.add(new Emprestimo(2, 876532, 222, LocalDate.of(2020, 03, 02), LocalDate.of(2020, 04, 02), false));
        emprestimos.add(new Emprestimo(3, 845214, 333, LocalDate.of(2020, 04, 22), LocalDate.of(2020, 04, 22), true));
   
        
        //Printar livros não devolvidos (livro 1 e livro 2)
        for (Emprestimo emp: emprestimos){
            if (emp.Devolvido() == false){
                    System.out.println("");
                    System.out.println(emp);
            }
        }
        
        //Printar livros devolvidos (livro 3).
        for (Emprestimo emp: emprestimos){
            if (emp.getId() == 3){
                emp.setDevolvido(true);
            }
        }
        
        for (Emprestimo emp : emprestimos){
            if (emp.Devolvido() == true){
                    System.out.println(emp);
            }
        }

    }
}


