
package Trabalho;

//uso do extends para pegar informações da classe usuario...
public class Livro extends Usuario{

    private int idLivro;
    private String titulo;
    private String autor;
    private String edicao;
    private String editora;
    private String cidade;
    private int anopublicacao;

    public Livro() {
    }

    public Livro(int idLivro, String titulo, String autor, String edicao, String editora, String cidade, int anopublicacao) {
        this.idLivro = idLivro;
        this.titulo = titulo;
        this.autor = autor;
        this.edicao = edicao;
        this.editora = editora;
        this.cidade = cidade;
        this.anopublicacao = anopublicacao;
    }
    public Livro(int idLivro, String titulo, String autor, String edicao, String editora, String cidade, int anopublicacao, int idUsuario, String nome, String email, String senha){
      super(idUsuario, nome, email, senha);
      this.idLivro = idLivro;
      this.titulo = titulo;
      this.autor = autor;
      this.edicao = edicao;
      this.editora = editora;
      this.cidade = cidade;
      this.anopublicacao = anopublicacao;
    }
//getters e setters
    public int getIdLivro() {
        return idLivro;
    }

    public void setIdLivro(int idLivro) {
        this.idLivro = idLivro;
    }

 

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEdicao() {
        return edicao;
    }

    public void setEdicao(String edicao) {
        this.edicao = edicao;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public int getAnopublicacao() {
        return anopublicacao;
    }

    public void setAnopublicacao(int anopublicacao) {
        this.anopublicacao = anopublicacao;
    }

    @Override
    public String toString() {
        return "Livro{" + "id=" + idLivro + ", titulo=" + titulo + ", autor=" + autor + ", edicao=" + edicao + ", editora=" + editora + ", cidade=" + cidade + ", anopublicacao=" + anopublicacao + '}';
    }
}
